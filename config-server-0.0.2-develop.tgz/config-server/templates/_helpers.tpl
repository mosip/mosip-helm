{{/*
Expand the name of the chart.
*/}}
{{- define "config-server.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "config-server.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "config-server.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "config-server.labels" -}}
helm.sh/chart: {{ include "config-server.chart" . }}
{{ include "config-server.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "config-server.selectorLabels" -}}
app.kubernetes.io/name: {{ include "config-server.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "config-server.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "config-server.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Determine if there are any native repos in the spring composite repos.
*/}}
{{- define "config-server.hasNative" -}}
{{- $hasNative := false -}}
{{- range .Values.spring_profiles.spring_compositeRepos }}
  {{- if eq .type "native" }}
    {{- $hasNative = true -}}
  {{- end }}
{{- end }}
{{- $hasNative -}}
{{- end -}}

{{/*
Return "true" when the config repo volume must be mounted: local repo is enabled,
or a composite repo of type native is configured.
*/}}
{{- define "config-server.needsVolume" -}}
{{- if or .Values.localRepo.enabled (and .Values.spring_profiles.enabled (eq (include "config-server.hasNative" .) "true")) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}
